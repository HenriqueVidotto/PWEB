var numero1 = prompt("numero 1");
var numero2 = prompt("numero 2");
numero1 = parseFloat(numero1);
numero2 = parseFloat(numero2);


var soma = numero1 + numero2;
var sub = numero1 - numero2;
var mult = numero1 * numero2;
var div = numero1 / numero2;
var resto = numero1 % numero2;


alert("Soma = " + soma + "\n Subtração = " + sub + "\n divisão = " + div + "\nMultiplicação = " + mult + "\nResto = " + resto)