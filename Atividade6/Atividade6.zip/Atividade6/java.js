var nome = prompt("nome");

var numero1 = prompt("Nota 1");
var numero2 = prompt("Nota 2");
var numero3 = prompt("Nota 3");


 numero1 = parseFloat(numero1);
 numero2 = parseFloat(numero2);
 numero3 = parseFloat(numero3);


    var media = ((numero1 + numero2 + numero3)/3);
    alert(" Nome : "+nome+"\nMedia = " + media);

